package method.runtime;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.random.RandomGenerator;
import method.runtime.SolverContracts.C;
import method.runtime.SolverContracts.LocalContext;
import method.runtime.SolverContracts.LocalPlan;
import method.runtime.SolverContracts.LocalResult;
import method.runtime.SolverContracts.SatelliteView;
import model.ProblemInstance;
import model.ScheduledTask;
import model.TimeWindow;
import utils.TimeUtils;

/** Project adaptation of RKHMA's first-feasible greedy observation insertion. */
public final class C000003 implements C {
  @Override public List<ScheduledTask> build(ProblemInstance problem, ProblemAccess api, SatelliteView view,
      List<Integer> priorities, Budget budget, RandomGenerator rng) {
    budget.check();
    return decode(problem, api, view.satelliteId(), List.of(), priorities, Set.of(), budget);
  }

  @Override public List<ScheduledTask> rebuild(ProblemInstance problem, ProblemAccess api, SatelliteView view,
      LocalContext context, List<Integer> priorities, Budget budget, RandomGenerator rng) {
    budget.check();
    Set<Integer> preferred = context.preferredWindowTasks();
    if (!preferred.isEmpty() && !sourceCompatible(problem, view.satelliteId(), budget)) preferred = Set.of();
    return decode(problem, api, view.satelliteId(), List.of(), priorities, preferred, budget);
  }

  @Override public LocalResult applyLocal(ProblemInstance problem, ProblemAccess api, SatelliteView view,
      LocalContext context, LocalPlan plan, Budget budget, RandomGenerator rng) {
    budget.check();
    List<ScheduledTask> kept = new ArrayList<>();
    for (ScheduledTask observation : view.observations()) {
      budget.check();
      if (!plan.release().contains(observation.getTaskId())) kept.add(observation);
    }
    return LocalResult.applied(decode(problem, api, view.satelliteId(), kept,
        plan.reconsider(), Set.of(), budget));
  }

  private static List<ScheduledTask> decode(ProblemInstance problem, ProblemAccess api, int satellite,
      List<ScheduledTask> existing, List<Integer> order, Set<Integer> preferred, Budget budget) {
    List<ScheduledTask> schedule = new ArrayList<>(existing);
    schedule.sort(Comparator.comparingDouble(ScheduledTask::getStartTime));
    for (int task : order) {
      budget.check();
      if (schedule.stream().anyMatch(observation -> observation.getTaskId() == task)) continue;
      Map<TimeWindow, Integer> windowRanks = preferred.contains(task)
          ? rankedWindows(problem, api, satellite, task, budget) : Map.of();
      ScheduledTask selected = null;
      int selectedRank = Integer.MAX_VALUE;
      for (ScheduledTask candidate : api.candidates(task, satellite, budget)) {
        budget.check();
        int rank = windowRanks.isEmpty() ? 0 : windowRanks.get(candidate.timeWindow());
        if (rank >= selectedRank || !fits(schedule, candidate)) continue;
        selected = candidate;
        selectedRank = rank;
        if (rank == 0) break;
      }
      if (selected != null) {
        schedule.add(selected);
        schedule.sort(Comparator.comparingDouble(ScheduledTask::getStartTime));
      }
    }
    return List.copyOf(schedule);
  }

  private static boolean fits(List<ScheduledTask> schedule, ScheduledTask candidate) {
    int index = 0;
    while (index < schedule.size() && schedule.get(index).getStartTime() < candidate.getStartTime()) index++;
    ScheduledTask previous = index == 0 ? null : schedule.get(index - 1);
    ScheduledTask next = index == schedule.size() ? null : schedule.get(index);
    return (previous == null || (candidate.getStartTime() >= previous.getEndTime()
        && TimeUtils.checkTransformationTime(previous.endRecord(), candidate.startRecord())))
        && (next == null || (next.getStartTime() >= candidate.getEndTime()
        && TimeUtils.checkTransformationTime(candidate.endRecord(), next.startRecord())));
  }

  private static Map<TimeWindow, Integer> rankedWindows(ProblemInstance problem, ProblemAccess api,
      int satellite, int task, Budget budget) {
    int taskIndex = 0;
    while (problem.tasks().get(taskIndex).getId() != task) { budget.check(); taskIndex++; }
    int satelliteIndex = 0;
    while (problem.satellites().get(satelliteIndex).getId() != satellite) { budget.check(); satelliteIndex++; }
    final int sourceTask = taskIndex;
    final int sourceSatellite = satelliteIndex;
    List<TimeWindow> windows = new ArrayList<>(api.windows(task, satellite));
    windows.sort(Comparator.comparingDouble((TimeWindow window) ->
        windowScore(window, sourceTask, sourceSatellite)).reversed()
        .thenComparingDouble(TimeWindow::getStartTime).thenComparingDouble(TimeWindow::getEndTime));
    Map<TimeWindow, Integer> ranks = new IdentityHashMap<>();
    for (int i = 0; i < windows.size(); i++) { budget.check(); ranks.put(windows.get(i), i); }
    return ranks;
  }

  private static double windowScore(TimeWindow window, int taskIndex, int satelliteIndex) {
    long hash = 1469598103934665603L;
    hash = (hash ^ taskIndex) * 1099511628211L;
    hash = (hash ^ satelliteIndex) * 1099511628211L;
    hash = (hash ^ Double.doubleToLongBits(window.getStartTime())) * 1099511628211L;
    hash = (hash ^ Double.doubleToLongBits(window.getEndTime())) * 1099511628211L;
    double noise = (hash & Long.MAX_VALUE) / (double) Long.MAX_VALUE;
    return -window.getStartTime() * 1.0e-3
        + Math.max(0.0, window.getEndTime() - window.getStartTime()) + noise * 1.0e-2;
  }

  private static boolean sourceCompatible(ProblemInstance problem, int satellite, Budget budget) {
    for (TimeWindow window : problem.satellite(satellite).getTimeWindows()) {
      budget.check();
      List<model.AttitudeRecord> records = window.getAttitudeRecords();
      for (int i = 1; i < records.size() - 1; i++) {
        budget.check();
        double time = records.get(i).getTotalSeconds();
        if (time < window.getStartTime() || time > window.getEndTime()) return false;
        if (i > 1 && time - records.get(i - 1).getTotalSeconds() != 1.0) return false;
      }
    }
    return true;
  }
}
